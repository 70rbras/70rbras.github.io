# Apresentação oral da 70ª RBras (Comunicação Oral e Sessão Temática)

Dois modelos oficiais, com o mesmo resultado projetado: um arquivo de
PowerPoint e um tema do Beamer. Escolha um deles. As regras de conteúdo,
a paleta, as fontes e os problemas comuns estão no manual.

## Arquivos

| arquivo | função |
|---|---|
| `Manual_Apresentacao_70RBras.pdf` | manual de uso dos dois modelos |
| `PowerPoint/Template_Apresentacao_70RBras.pptx` | modelo em PowerPoint: 13 layouts e slides de exemplo, Montserrat embutida |
| `Beamer/beamerthemerbras.sty` | tema: geometria, layouts e estilos de gráfico |
| `Beamer/beamercolorthemerbras.sty` | paleta e cores |
| `Beamer/beamerfontthemerbras.sty` | tipografia e corpos de fonte |
| `Beamer/apresentacao.tex` | exemplo com os 13 layouts; traz os dados simulados em blocos `filecontents` |
| `Beamer/apresentacao.pdf` | exemplo já compilado |
| `Beamer/logo-rbras.png` | logo do evento |
| `Beamer/logo-instituicao.png` | logo do IMECC, para trocar pelo da sua instituição |
| `Beamer/simula.R`, `Beamer/simula.py` | geram os dados do exemplo (R ou Python) |

## Compilar o modelo Beamer

```
cd Beamer
pdflatex apresentacao.tex
```

O tema usa o pacote `montserrat`. Sem ele, recorre à Helvetica e compila
mesmo assim, com aviso no log. Para instalar: `tlmgr install montserrat`.

## Entrega

Apresente a partir de um PDF. O envio do arquivo segue as instruções do
e-mail da organização com o título "Envio da sua Apresentação para a 70a
RBRas", específicas para a sua sessão.
