# Pôster A0 da 70ª RBras em LaTeX

Recriação do `Template_Poster_70RBras.pptx` em LaTeX. A compilação é direta,
sem passo anterior nem pacote fora da TeX Live. Os comandos abaixo bastam.

```
cd LaTeX
pdflatex poster.tex
```

## Arquivos

| arquivo | função |
|---|---|
| `Manual_Poster_70RBras.pdf` | manual de uso dos dois modelos |
| `PowerPoint/Template_Poster_70RBras.pptx` | modelo em PowerPoint, com as áreas de plotagem alinhadas |
| `LaTeX/poster.tex` | documento do pôster; traz os dados simulados em blocos `filecontents` |
| `LaTeX/rbras-poster.cls` | classe com a identidade visual, a geometria e os estilos de gráfico |
| `LaTeX/poster.pdf` | pôster de exemplo já compilado |
| `LaTeX/logo-rbras.png` | logo do evento, extraído do template original |
| `LaTeX/logo-instituicao.png` | logo do IMECC, para trocar pelo da sua instituição |
| `LaTeX/simula.R` | gera `fig1.csv`, `fig2.csv` e `tab1.csv` |
| `LaTeX/simula.py` | versão em Python do mesmo gerador |
| `LaTeX/fig1.csv`, `LaTeX/fig2.csv`, `LaTeX/tab1.csv` | dados do exemplo |

Os três CSV são gravados pelo próprio LaTeX a cada compilação, a partir dos
blocos `filecontents` no início de `poster.tex`. Esses blocos são a fonte
única dos números impressos. Ao regerar os dados com `simula.R`, copie o
conteúdo dos CSV de volta para dentro do `.tex`.

## Dependências

A classe usa `montserrat` para o texto. Se o pacote não estiver instalado ela
recorre a Helvetica, emite aviso no log e compila assim mesmo. Em TeX Live
instale com o comando a seguir.

```
tlmgr install montserrat
```

A hifenização em português depende de `babel-portuges` com `hyphen-portuguese`.
A classe também torna esse par opcional. Sem ele o documento compila, porém sem
hifenizar.

## Dados do exemplo

O exemplo é uma simulação do estimador de encolhimento de Stein, com
`Y ~ N_p(mu, I)`. A Figura 1 e a Tabela 1 são médias de Monte Carlo, com
400.000 e 2.000.000 de réplicas. O erro padrão de Monte Carlo fica abaixo de
0,002 nas quantidades impressas, de modo que as duas casas decimais não mudam
com a semente nem com o gerador de números aleatórios.

A Figura 2 é diferente: mostra uma única realização, com semente 1. Trocar a
semente muda os números no gráfico. Nesse caso é preciso reescrever os rótulos
do bloco correspondente em `poster.tex`.

## Comandos da classe

Os metadados vão no preâmbulo: `\titulo`, `\autores`, `\afiliacoes`, `\email`,
`\mensagem`, `\qrlink`, `\logoevento`, `\logoinstituicao`, `\conclusoes`,
`\referencias` e `\agradecimentos`. O corpo tem dois ambientes de coluna,
`colunaesquerda` e `colunadireita`, e dentro deles o ambiente `secao`, que
recebe o número e o título. Para conteúdo há `\figura`, `\tabela`,
`\duasfiguras`, a caixa `caixaequacao` e os comandos `\inclinacao` e
`\inclinacaodestaque` do gráfico de inclinação.

O `\qrlink` vazio desenha o quadro tracejado do template. Com uma URL dentro
dele o QR code é gerado pelo próprio LaTeX, sem arquivo de imagem. Em URLs com
`%` ou `#` escreva `\%` e `\#`.

O bloco de figura tem geometria fixa, de 620 por 980 bp, com o título em 0, o
rótulo em 120, o gráfico em 205 e a legenda em 900. A área de plotagem ocupa
72% da largura e 88% da altura da moldura. Por isso as duas figuras ficam
alinhadas mesmo com títulos de números de linhas diferentes. O terceiro
argumento de `\figura` é só o ambiente `axis`, sem `tikzpicture` em volta: a
moldura é criada pela classe.

A faixa de conclusões fica fixa em 2710 bp a partir do topo, como no template.
Se o conteúdo das colunas crescer e invadir essa faixa, desça-a com
`\posicaoconclusoes{2850}`, por exemplo. Também é possível estreitar ou alargar
as colunas com o argumento opcional, como em `\begin{colunaesquerda}[860bp]`.
