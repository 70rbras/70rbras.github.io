# Equivalente em R de simula.py. Gera fig1.csv, fig2.csv e tab1.csv.
# Os geradores de numeros aleatorios de R e de NumPy diferem, entao as
# amostras nao sao identicas. Os valores impressos no poster tem duas casas
# decimais e o erro padrao de Monte Carlo e inferior a 0,002, de modo que os
# numeros arredondados coincidem. A Figura 2 usa uma unica realizacao: com
# semente diferente ela muda, e os rotulos do poster devem ser refeitos.
#
# Uso: Rscript simula.R

REPL_FIG <- 4e5
REPL_TAB <- 2e6
SEMENTE  <- 1

eqm <- function(p, mu2, repl, semente) {
  set.seed(semente)
  mu <- rep(sqrt(mu2 / p), p)
  Y  <- matrix(rnorm(repl * p), repl, p) + rep(mu, each = repl)
  S  <- rowSums(Y^2)
  D  <- Y * (1 - (p - 2) / S)
  c(usual = mean(rowSums((Y - rep(mu, each = repl))^2)),
    stein = mean(rowSums((D - rep(mu, each = repl))^2)))
}

figura1 <- function(arquivo = "fig1.csv") {
  p <- 2:10
  r <- sapply(p, function(pp) { e <- eqm(pp, pp, REPL_FIG, SEMENTE); e[2] / e[1] })
  write.csv(data.frame(p = p, usual = 1, stein = round(r, 2)),
            arquivo, row.names = FALSE, quote = FALSE)
}

figura2 <- function(arquivo = "fig2.csv") {
  theta <- c(8, 7, 6, 5, 4)
  n     <- c(200, 120, 60, 25, 10)
  sigma <- 6
  nomes <- c("A", "B", "C", "D", "E")
  k <- length(theta)
  v <- sigma^2 / n
  set.seed(SEMENTE)
  y      <- theta + rnorm(k) * sqrt(v)
  ybarra <- mean(y)
  tau2   <- max(0, (sum((y - ybarra)^2) - sum(v) * (1 - 1 / k)) / (k - 1))
  B      <- tau2 / (tau2 + v)
  d      <- ybarra + B * (y - ybarra)
  write.csv(data.frame(regiao = nomes, n = n,
                       usual = round(y, 1), encolhida = round(d, 1)),
            arquivo, row.names = FALSE, quote = FALSE)
}

tabela1 <- function(arquivo = "tab1.csv") {
  cen <- data.frame(p = c(5, 5, 10), mu2 = c(5, 20, 10))
  res <- t(mapply(function(p, m) eqm(p, m, REPL_TAB, SEMENTE), cen$p, cen$mu2))
  write.csv(data.frame(p = cen$p, mu2 = cen$mu2,
                       usual = round(res[, 1], 1), stein = round(res[, 2], 1),
                       reducao = round(100 * (1 - res[, 2] / res[, 1]))),
            arquivo, row.names = FALSE, quote = FALSE)
}

figura1(); figura2(); tabela1()
