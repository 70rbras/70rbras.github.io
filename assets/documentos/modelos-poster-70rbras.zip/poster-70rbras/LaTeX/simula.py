#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Gera os dados simulados do poster da 70a RBras.

Modelo: Y ~ N_p(mu, I), com mu = (c, ..., c) e ||mu||^2 fixado.
Estimador usual:        d_u(Y) = Y
Estimador de Stein:     d_s(Y) = (1 - (p-2)/||Y||^2) Y

Saidas:
  fig1.csv   EQM relativo ao usual, por p
  fig2.csv   medias por regiao, usual e encolhida (areas pequenas)
  tab1.csv   EQM absoluto e reducao, por p e forca do sinal

Uso: python3 simula.py
"""
import numpy as np

REPL_FIG = 400_000
REPL_TAB = 2_000_000
SEMENTE = 1


def eqm(p, mu2, repl, semente):
    """EQM do estimador usual e do de Stein, por Monte Carlo."""
    rng = np.random.default_rng(semente)
    mu = np.full(p, np.sqrt(mu2 / p))
    Y = rng.standard_normal((repl, p)) + mu
    S = (Y ** 2).sum(1)
    D = (1 - (p - 2) / S)[:, None] * Y
    pe_u = ((Y - mu) ** 2).sum(1)
    pe_s = ((D - mu) ** 2).sum(1)
    return (pe_u.mean(), pe_s.mean(),
            pe_u.std(ddof=1) / np.sqrt(repl), pe_s.std(ddof=1) / np.sqrt(repl))


def figura1(caminho="fig1.csv"):
    linhas = ["p,usual,stein"]
    erros = []
    for p in range(2, 11):
        u, s, eu, es = eqm(p, p, REPL_FIG, SEMENTE)
        linhas.append("%d,%.2f,%.2f" % (p, 1.0, s / u))
        erros.append((p, s / u, es / u))
    open(caminho, "w").write("\n".join(linhas) + "\n")
    return erros


def figura2(caminho="fig2.csv"):
    """Cinco regioes; media por regiao e encolhimento para a media global.

    theta: media verdadeira; n: tamanho da amostra; sigma: desvio na populacao.
    Encolhimento empirico de Bayes: B_j = tau2 / (tau2 + sigma^2/n_j).
    """
    theta = np.array([8.0, 7.0, 6.0, 5.0, 4.0])
    n = np.array([200.0, 120.0, 60.0, 25.0, 10.0])
    sigma = 6.0
    nomes = ["A", "B", "C", "D", "E"]
    k = len(theta)
    v = sigma ** 2 / n
    rng = np.random.default_rng(SEMENTE)
    y = theta + rng.standard_normal(k) * np.sqrt(v)
    ybarra = y.mean()
    tau2 = max(0.0, (((y - ybarra) ** 2).sum() - v.sum() * (1 - 1 / k)) / (k - 1))
    B = tau2 / (tau2 + v)
    d = ybarra + B * (y - ybarra)
    linhas = ["regiao,n,usual,encolhida"]
    for i in range(k):
        linhas.append("%s,%d,%.1f,%.1f" % (nomes[i], n[i], y[i], d[i]))
    open(caminho, "w").write("\n".join(linhas) + "\n")
    eqm_u = ((y - theta) ** 2).sum()
    eqm_d = ((d - theta) ** 2).sum()
    return tau2, B, eqm_u, eqm_d


def tabela1(caminho="tab1.csv"):
    linhas = ["p,mu2,usual,stein,reducao"]
    saida = []
    for p, mu2 in [(5, 5), (5, 20), (10, 10)]:
        u, s, eu, es = eqm(p, mu2, REPL_TAB, SEMENTE)
        red = round(100 * (1 - s / u))
        linhas.append("%d,%d,%.1f,%.1f,%d" % (p, mu2, u, s, red))
        saida.append((p, mu2, u, s, red, eu, es))
    open(caminho, "w").write("\n".join(linhas) + "\n")
    return saida


if __name__ == "__main__":
    e1 = figura1()
    print("Figura 1 - EQM relativo (erro padrao de Monte Carlo):")
    for p, r, se in e1:
        print("  p=%2d  rel=%.4f  ep=%.5f" % (p, r, se))
    tau2, B, u, d = figura2()
    print("\nFigura 2 - tau2=%.2f  B=%s" % (tau2, np.round(B, 2)))
    print("  EQM usual=%.2f  encolhido=%.2f  reducao=%.0f%%"
          % (u, d, 100 * (1 - d / u)))
    print("\nTabela 1:")
    for p, mu2, u, s, red, eu, es in tabela1():
        print("  p=%2d  ||mu||2=%2d  usual=%.3f (ep %.4f)  stein=%.3f (ep %.4f)"
              "  reducao=%d%%" % (p, mu2, u, eu, s, es, red))
